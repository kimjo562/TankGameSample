| Joseph Kim|
| :---          	|
| s198022       	|
| A1US - AOS - Maths for Games |
| Tank Graphical Test Documentation |

## I. Requirements

1. Description of Problem

	- **Name**: Graphical Game Project

	- **Problem Statement**:
	Creation of a game project using the C# programming language and create a visual graphical game within Visual Studios

	- **Problem Specifications**:  The game must include: Vectors, Matrixs, and a collection of C# classes, functions, and hierarchys used to make a game, and to test the accuracy of your mathmatical methods.

2. Input Information
- **Controls to the Tank Game**
     - Use Arrow Keys to Move the Pilot, and the Tank.
     - Left and Right Arrows to turn while in the Tank.
     - Z to Enter the Tank.
     - X to Exit the Tank.
     - Q and E to rotate the barrel of the Tank.
     - Space Bar to shoot bullets from the Tank.

3.  Output Information
-The program displays a window that will show a Tank that is able to move and shoot.
    - **Blue Tank**: The user's tank upon the game starting the program. The Tank can shoot and rotate its barrel independently from the tank's rotation.
    - **Pilot**: The user's pilot, when the user gets out of the Tank.

|
1. _User Interface_

### Tank Example

|![User Interface gif](https://i.imgur.com/ePgWIQj.png)

### Pilot Example

|![User Interface gif](https://i.imgur.com/4wcXgtl.png)
 

3. ### Object Information(All classes and their atrributes shsould be described here.)

   **File**: Game.cs

     Description: Handles all the math using Matrices 3x3 including transformations and rotations.

    **Attributes**

         Name: Game
             Description: Constructor for Matrix3, Makes Matrix3 for a 2D space.
             Type: class constructor
             Visiblity: public
             Arguments: int, int, string

        Name: Run
             Description: Run the game loop
             Type: class constructor
             Visibility: public

        Name: Root
             Description: The Actor we are currently running
             Type: class
             Visiblity: public

     **Operations**:

        Name: _root
             Description: The current root Actor
             Type: class
             Visibility: private

        Name: _next
             Description: The next root Actor
             Type: class
             Visibility: private

        Name: _gameTimer
             Description: The timer for the entire game
             Type: class
             Visibility: private


     **File**: Entity.cs

     Description: Handles creating and printing the Graphics on the screen.
    **Attributes**

         Name: XVelocity
             Description: Returns and set velocity of X.
             Visibility: public
             Type: float

        Name: YVelocity
             Description: Returns and set velocity of Y.
             Visibility: public
             Type: float

        Name: XAcceleration
             Description: Returns and set acceleration of X.
             Visibility: public
             Arguments: string

        Name: YAcceleration
             Description: Returns and set acceleration of Y.
             Visibility: public
             Type: floaty

        Name: Entity
             Description: Draws the Sprite to the Screen
             Visibility: public
             Type: override bool
             Argument: float, float

        Name: Update
             Description: Draws the Sprite to the Screen
             Visibility: public
             Type: override bool
             Argument: float

     **Operations**:

        Name: _velocity
             Description: The speed of an object.
             Type: class
             Visibility: private

        Name: _acceleration
             Description: The acceleration of an object.
             Type: class
             Visibility: private


   **File**: Matrix3.cs

     Description: Handles all the math using Matrices 3x3 including transformations and rotations.

    **Attributes**

         Name: Matrix3
             Description: Constructor for Matrix3, Makes Matrix3 for a 2D space.
             Type: class constructor

        Name: Matrix3
             Description: Constructor override for Matrix3, Makes Matrix3 with the specified values.
             Type: class constructor

        Name: Set
             Description: Sets this Matrix3 to the specified values.
             Visibility: public
             Type: void
             Arguments: float(x9)

        Name: Set
             Description: Sets this Matrix3 to the specified Matrix3.
             Visibility: public
             Type: static
             Arguments: class type

        Name: Matrix3 operator
             Description: Math for (Matrix3 * Vector3).
             Visibility: public
             Type: static operator
             Arguments: class type, class type

        Name: Vector3 operator
             Description: Math for (Matrix3 * Vector3).
             Visibility: public
             Type: static operator
             Arguments: class type, class type

        Name: SetScaled
             Description: Sets the Scale of the Entity/Sprite.
             Visibility: public
             Type: void
             Arguments: float, float, float

        Name: Scale
             Description: Increases or Decreases the Size (Scale).
             Visibility: public
             Type: void
             Arguments: float, float, float

        Name: SetRotateX
             Description: Sets the Rotation on the x Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: SetRotateY
             Description: Sets the Rotation on the y Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: SetRotateZ
             Description: Sets the Rotation on the z Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: RotateX
             Description: Rotates on the x Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: RotateY
             Description: Rotates on the y Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: RotateZ
             Description: Rotates on the z Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: SetTranslation
             Description: Sets the Translation of the Entity/Sprite.
             Visibility: public
             Type: void
             Arguments: float, float, float

        Name: Translate
             Description: Translate of the Entity/Sprite (has vector offset).
             Visibility: public
             Type: void
             Arguments: float, float, float

   **File**: Matrix4.cs

     Description: Handles all the math using Matrices 3x3 including transformations and rotations.

    **Attributes**

         Name: Matrix4
             Description: Constructor for Matrix4, Makes Matrix4 for a 3D space.
             Type: class constructor

        Name: Matrix4
             Description: Constructor override for Matrix4, Makes Matrix4 with the specified values.
             Type: class constructor

        Name: Set
             Description: Sets this Matrix4 to the specified values.
             Visibility: public
             Type: void
             Arguments: float(x16)

        Name: Set
             Description: Sets this Matrix4 to the specified Matrix3.
             Visibility: public
             Type: static
             Arguments: class type

        Name: Matrix3 operator
             Description: Math for (Matrix4 * Vector4).
             Visibility: public
             Type: static operator
             Arguments: class type, class type

        Name: Vector4 operator
             Description: Math for (Matrix4 * Vector4).
             Visibility: public
             Type: static operator
             Arguments: class type, class type

        Name: SetScaled
             Description: Sets the Scale of the Entity/Sprite.
             Visibility: public
             Type: void
             Arguments: float, float, float

        Name: Scale
             Description: Increases or Decreases the Size (Scale).
             Visibility: public
             Type: void
             Arguments: float, float, float

        Name: SetRotateX
             Description: Sets the Rotation on the x Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: SetRotateY
             Description: Sets the Rotation on the y Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: SetRotateZ
             Description: Sets the Rotation on the z Axis.
             Visibility: public
             Type: void
             Arguements: double

        Name: RotateX
             Description: Rotates on the x Axis.
             Visibility: public
             Type: void
             Arguements: double

        Name: RotateY
             Description: Rotates on the y Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: RotateZ
             Description: Rotates on the z Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: SetTranslation
             Description: Sets the Translation of the Entity/Sprite.
             Visibility: public
             Type: void
             Arguments: float, float, float

        Name: Translate
             Description: Translate of the Entity/Sprite (has vector offset).
             Visibility: public
             Type: void
             Arguments: float, float, float

    **File**: Vector3.cs

     Description: Handles Math and support for Matrix3
    **Attributes**

         Name: Vector3
             Description: Constructor for Vector3, Makes x,y,z to 0.
             Type: class constructor

         Name: Vector3
             Description: Constructor for Vector3, Makes x,y,z to 0.
             Type: class constructor

        Name: Vector3 operator (addition)
             Description: Sets this Matrix4 to the specified values.
             Visibility: public
             Type: void
             Arguments: float(x16)

        Name: Vector3 operator (subtraction)
             Description: Sets this Matrix4 to the specified Matrix3.
             Visibility: public
             Type: static
             Arguments: class type

        Name: Vector3 operator (multiplication left)
             Description: Math for (Matrix4 * Vector4).
             Visibility: public
             Type: static operator
             Arguments: class type, class type

        Name: Vector3 operator (multiplication right)
             Description: Math for (Matrix4 * Vector4).
             Visibility: public
             Type: static operator
             Arguments: class type, class type

        Name: Vector3 operator (division left)
             Description: Sets the Scale of the Entity/Sprite.
             Visibility: public
             Type: void
             Arguments: float, float, float

        Name: Vector3 operator (division right)
             Description: Increases or Decreases the Size (Scale).
             Visibility: public
             Type: void
             Arguments: float, float, float

        Name: Magnitude
             Description: Sets the Rotation on the x Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: Normalize
             Description: Sets the Rotation on the y Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: DotProduct
             Description: Sets the Rotation on the z Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: CrossProduct
             Description: Rotates on the x Axis.
             Visibility: public
             Type: void
             Arguments: double


    **File**: Vector4.cs

     Description: Used to in the shop to store attacks to be bought by the player.
    **Attributes**

         Name: Vector4
             Description: Constructor for Vector4, Makes x,y,z,w to 0.
             Type: class constructor

         Name: Vector4
             Description: Constructor for Vector4, Makes x,y,z,w to 0.
             Type: class constructor

        Name: Vector4 operator (addition)
             Description: Sets this Matrix4 to the specified values.
             Visibility: public
             Type: void
             Arguments: float(x16)

        Name: Vector4 operator (subtraction)
             Description: Sets this Matrix4 to the specified Matrix4.
             Visibility: public
             Type: static
             Arguments: class type

        Name: Vector4 operator (multiplication left)
             Description: Math for (Matrix4 * Vector4).
             Visibility: public
             Type: static operator
             Arguments: class type, class type

        Name: Vector4 operator (multiplication right)
             Description: Math for (Matrix4 * Vector4).
             Visibility: public
             Type: static operator
             Arguments: class type, class type

        Name: Vector4 operator (division left)
             Description: Sets the Scale of the Entity/Sprite.
             Visibility: public
             Type: void
             Arguments: float, float, float

        Name: Vector4 operator (division right)
             Description: Increases or Decreases the Size (Scale).
             Visibility: public
             Type: void
             Arguments: float, float, float

        Name: Magnitude
             Description: Sets the Rotation on the x Axis.
             Visibility: public
             Type: void
             Arguements: double

        Name: Normalize
             Description: Sets the Rotation on the y Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: DotProduct
             Description: Sets the Rotation on the z Axis.
             Visibility: public
             Type: void
             Arguments: double

        Name: CrossProduct
             Description: Rotates on the x Axis.
             Visibility: public
             Type: void
             Arguments: double


    **File**: Input.cs

     Description: What allows the user to return keystroke to the tank to do actions.
    **Attributes**

         Name: IsKeyPressed (using Raylib)
             Description: Whenever a key is pressed once, it will take action.
             Visibility: public
             Type: static bool
             Arguements: int

         Name: IsKeyDown (using Raylib)
             Description: Whenever a key is held down, it will take action.
             Visibility: public
             Type: static bool
             Arguements: int

         Name: IsKeyReleased (using Raylib)
             Description: Whenever a key is released, it will take action.
             Visibility: public
             Type: static bool
             Arguements: int

         Name: IsKeyUp (using Raylib)
             Description: Whenever a key is up, it will take action.
             Visibility: public
             Type: static bool
             Arguements: int

     **File**: Sprite.cs

     Description: Handles creating and printing the Graphics on the screen.
    **Attributes**

         Name: Width
             Description: Grabs and returns the width of the texture.
             Visibility: public
             Type: float

        Name: Height
             Description: Grabs and returns the height of the texture.
             Visibility: public
             Type: float

        Name: Sprite
             Description: Default constructor for sprite that prints and offsets the sprite/texture correctly.
             Visibility: public
             Type: class constructor
             Arguements: string

        Name: Draw
             Description: Draws the Sprite to the Screen
             Visibility: public
             Type: override bool

     **Operations**:

        Name: _texture
             Description: Uses the Raylib 2D texture to create 2D Sprites.
             Type: Texture2D (using Raylib)
             Visibility: private
        Name: _image
             Description: usesw the Raylib image to create sprites on the screen.
             Type: Image (using Raylib)
             Visibility: private


 **File**: Timer.cs

     Description: Handles with time.
    **Attributes**

         Name: Timer
             Description: Grabs and returns the width of the texture.
             Visibility: public
             Type: class constructor

        Name: Restart
             Description: Resets the timer.
             Visibility: public
             Type: void

        Name: Seconds
             Description: The time in seconds
             Visibility: public
             Type: float

        Name: GetDeltaTime
             Description: Gets the DeltaTime
             Visibility: public
             Type: float

     **Operations**:

        Name: _stopwatch
             Description: stopwatch for time.
             Type: class
             Visibility: private

        Name: _currentTime
             Description: Grabs the current time passed.
             Type: long
             Visibility: private

        Name: _previousTime
             Description: Grabs and uses the previous time passed.
             Type: long
             Visibility: private

        Name: _deltaTime
             Description: Makes objects and speed not frame dependent.
             Type: float
             Visibility: private


 **File**: AABB.cs

     Description: Handles everything with collision and hit detection(hitboxes)
    **Attributes**

         Name: Top
             Description: Gets the Top Screen Side
             Visibility: public
             Type: float

        Name: Bottom
             Description: Gets the Bottom Screen Side
             Visibility: public
             Type: float

        Name: Left
             Description: Gets the Left Screen Side
             Visibility: public
             Type: float

        Name: Right
             Description: Gets the Right Screen Side
             Visibility: public
             Type: float

         Name: AABB
             Description: Creates an AABB of the specifed size
             Visibility: public
             Type: class constructor
             Arguments: float, float

        Name: DetectCollision
             Description: AABB Collision Detection
             Visibility: public
             Type: bool
             Arguments: class

        Name: DetectCollision
             Description: Vector3 Collision Detection
             Visibility: public
             Type: bool
             Arguments: class

        Name: Draw
             Description: Draws the bounding box to the screen
             Visibility: public
             Type: void
             Argument: override

     **Operations**:

        Name: Width
             Description: Gets AABB Width
             Type: float
             Visibility: public

        Name: Height
             Description: Gets AABB Height
             Type: long
             Visibility: public

        Name: _color (using Raylib)
             Description: Uses Raylib color for Hitbox color
             Type: struct
             Visibility: private


 **File**: Actor.cs

     Description: Handles everything with collision and hit detection(hitboxes)
    **Attributes**

         Name: X
             Description: The Entity's location on the X axis
             Visibility: public
             Type: float

        Name: Y
             Description: The Entity's location on the Y axis
             Visibility: public
             Type: float

        Name: XAbsolute
             Description: The Entity's location on the X axis absolute
             Visibility: public
             Type: float

        Name: YAbsolute
             Description: The Entity's location on the Y axis absolute
             Visibility: public
             Type: float

         Name: GetDirection
             Description: Gets the relative position of direction
             Visibility: public
             Type: class

        Name: GetDirectionAbsolute
             Description: Gets the absolute position of direction
             Visibility: public
             Type: class

        Name: GetChildren
             Description: Call function of _children.
             Visibility: public
             Type: List<Actor>

        Name: GetRotation
             Description: Gets the relative rotation.
             Visibility: public
             Type: float

        Name: GetRotationAbsolute
             Description: Gets the absolute rotation.
             Visibility: public
             Type: float

        Name: Rotate
             Description: Lets the function rotate in radians.
             Visibility: public
             Type: float
             Argument: float

        Name: GetScale
             Description: Lets the function bigger or smaller.
             Visibility: public
             Type: float

        Name: GetScaleAbsolute
             Description:  getting the scale of _globalTransform
             Visibility: public
             Type: float

        Name: Scale
             Description: Immplementing scaling _localTransform
             Visibility: public
             Type: void
             Argument: float

        Name: AddChild
             Description: Implements AddChild.
             Visibility: public
             Type: void
             Argument: class

        Name: RemoveChild
             Description: Implements RemoveChild.
             Visibility: public
             Type: void
             Argument: class

        Name: UpdateTransform
             Description: Implments UpdateTransform.
             Visibility: public
             Type: void

        Name: Start
             Description: Call the OnStart events of the Actor and its children
             Visibility: public
             Type: virtual void

        Name: Update
             Description: Call the OnUpdate events of the Actor and its children
             Visibility: public
             Type: void
             Argument: float

        Name: Draw
             Description: Call the OnDraw events of the Actor and its children
             Visibility: public
             Type: virtual void

     **Operations**:

        Name: OnStart
             Description: Creates OnStart events
             Type: delegate
             Visibility: public

        Name: OnUpdate
             Description: Creates OnUpdate events
             Type: delegate
             Visibility: public
             Argument: float

        Name: OnDraw
             Description: Creates OnDraw events
             Type: delegate
             Visibility: public

        Name: Started
             Description: Starts the Game
             Type: bool
             Visibility: public

        Name: Parent
             Description: Sets Parent of root Null
             Type: class
             Visibility: public

        Name: _children
             Description: Hierarchy of Parent
             Type: List<Actor>
             Visibility: protected

        Name: _additions
             Description: The addition of _children (queue line)
             Type: List<Actor>
             Visibility: private

        Name: _removals
             Description: The removal of _children (queue line)
             Type: List<Actor>
             Visibility: private

        Name: _localTransform
             Description: Relative position of something.
             Type: class
             Visibility: private

        Name: _globalTransform
             Description: Absolute position of something.
             Type: class
             Visibility: private


 **File**: Pilot.cs

     Description: Pilot of the TankBody, acts as the Hull.
    **Attributes**

         Name: Pilot
             Description: Class Constructor of Pilot
             Visibility: public
             Type: class constructor

        Name: Pilot
             Description: Class Constructor Overloader of Pilot
             Visibility: public
             Type: class constructor

        Name: MoveUp
             Description: Lets the player and Tank Move Up
             Visibility: public
             Type: void
             Argument: float

        Name: MoveDown
             Description: Lets the player and Tank Move Down
             Visibility: public
             Type: void
             Argument: float

         Name: MoveLeft
             Description: Lets the player Move Left
             Visibility: public
             Type: void
             Argument: float

        Name: MoveRight
             Description: Lets the player Move Right
             Visibility: public
             Type: void
             Argument: float

        Name: TurnLeft
             Description: Lets the Tank Turn Right
             Visibility: public
             Type: void
             Argument: float

        Name: TurnRight
             Description: Lets the Tank Turn Right
             Visibility: public
             Type: void
             Argument: float

        Name: ZeroSpeed
             Description: Resets the Velocity and Acceleration
             Visibility: public
             Type: void

        Name: EnterTank
             Description: Lets the Pilot enter the tank.
             Visibility: public
             Type: void
             Argument: float

        Name: ExitTank
             Description: Lets the Pilot exit the tank.
             Visibility: public
             Type: void
             Argument: float

        Name: PilotReset
             Description: Resets the Pilot back to the tank's position
             Visibility: public
             Type: void
             Argument: float

        Name: Braking
             Description: Allows the Tank to brake and stop.
             Visibility: public
             Type: void
             Argument: float

        Name: DetectCollision
             Description: Checks for Pilot's hitbox collision detection
             Visibility: public
             Type: bool
             Argument: class

        Name: WrapScreen
             Description: Lets the Pilot loop across the screen.
             Visibility: public
             Type: void
             Argument: float

        Name: PositionFinder
             Description: Shows the position numbers of the Pilot
             Visibility: public
             Type: void

        Name: GetChildren
             Description: Calls for _children in List<Actor>
             Visibility: public
             Type: List<Actor>

     **Operations**:

        Name: _texture
             Description: Creates the texture for the Pilot
             Type: class
             Visibility: private

        Name: _hitbox
             Description: Creates the AABB for the Pilot
             Type: class
             Visibility: private

        Name: bodyTank
             Description: Creates a new instance of TankBody
             Type: class
             Visibility: private

        Name: isEntered
             Description: Used to check if the Pilot is inside the Tank
             Type: bool
             Visibility: private


 **File**: TankBody.cs

     Description: Tankbody of the TankTurret, acts as the Tank Base.
    **Attributes**

         Name: Tankbody
             Description: Class Constructor of TankBody
             Visibility: public
             Type: class constructor

        Name: TankBody
             Description: Class Constructor Overloader of TankBody
             Visibility: public
             Type: class constructor

        Name: DetectCollision
             Description: Checks for Pilot's hitbox collision detection
             Visibility: public
             Type: bool
             Argument: class

        Name: CollisionCheck
             Description: Checks to see if collision is true
             Visibility: public
             Type: bool
             Argument: class

        Name: PositionFinder
             Description: Shows the position numbers of the TankBody
             Visibility: public
             Type: void

     **Operations**:

        Name: _texture
             Description: Creates the texture for the TankBody
             Type: class
             Visibility: private

        Name: _hitbox
             Description: Creates the AABB for the TankBody
             Type: class
             Visibility: private

        Name: tankBarrel
             Description: Creates a new instance of TankTurret
             Type: class
             Visibility: private


 **File**: TankTurret.cs

     Description: TankTurret, part of the TankBody
    **Attributes**

         Name: TankTurret
             Description: Class Constructor of TankTurret
             Visibility: public
             Type: class constructor

        Name: TankTurret
             Description: Class Constructor Overloader of TankTurret
             Visibility: public
             Type: class constructor

        Name: RotateLeft
             Description: Lets the barrel rotate left.
             Visibility: public
             Type: void
             Argument: float

        Name: RotateRight
             Description: Lets the barrel rotate right.
             Visibility: public
             Type: void
             Argument: float

        Name: Shoot
             Description: Lets the TankBarrel Shoot out Bullets.
             Visibility: public
             Type: void
             Argument: float

     **Operations**:

        Name: _texture
             Description: Creates the texture for the TankTurret
             Type: class
             Visibility: private


 **File**: EnemyTank.cs

     Description: EnemyTank of the TankTurret, acts as the Tank Base.
    **Attributes**

         Name: EnemyTank
             Description: Class Constructor of EnemyTank
             Visibility: public
             Type: class constructor

        Name: TankBody
             Description: Class Constructor Overloader of EnemyTank
             Visibility: public
             Type: class constructor

        Name: MoveUp
             Description: Lets the Enemy Tanks move up.
             Visibility: public
             Type: void
             Argument: float

         Name: RandomizedPosition
             Description: Randomizes the location where the Enemy tanks moves when screen wrapping.
             Visibility: public
             Type: void
             Argument: float         

        Name: CollisionCheck
             Description: Checks to see if collision is true
             Visibility: public
             Type: bool
             Argument: class

        Name: PositionFinder
             Description: Shows the position numbers of the TankBody
             Visibility: public
             Type: void

     **Operations**:

        Name: _texture
             Description: Creates the texture for the TankBody
             Type: class
             Visibility: private

        Name: _hitbox
             Description: Creates the AABB for the TankBody
             Type: class
             Visibility: private

        Name: tankBarrel
             Description: Creates a new instance of TankTurret
             Type: class
             Visibility: private


 **File**: EnemyTankTurret.cs

     Description: EnemyTankTurret, part of the EnemyTankBody
    **Attributes**

         Name: EnemyTankTurret
             Description: Class Constructor of EnemyTankTurret
             Visibility: public
             Type: class constructor

        Name: EnemyTankTurret
             Description: Class Constructor Overloader of EnemyTankTurret
             Visibility: public
             Type: class constructor

        Name: RotateRight
             Description: Lets the barrel rotate right.
             Visibility: public
             Type: void
             Argument: float

        Name: Shoot
             Description: Lets the TankBarrel Shoot out Bullets.
             Visibility: public
             Type: void
             Argument: float

     **Operations**:

        Name: _texture
             Description: Creates the texture for the TankTurret
             Type: class
             Visibility: private

        Name: _timetoShoot
             Description: How long the Enemy tank takes to shoot.
             Type: class
             Visibility: private

        Name: _shootInterval
             Description: Fire rate of Enemy Tank.
             Type: float
             Visibility: private

        Name: random
             Description: Creates the instance of Random
             Type: class
             Visibility: private


 **File**: Bullet.cs

     Description: Bullet, projectile fired from the tanks.
    **Attributes**

         Name: Bullet
             Description: Class Constructor of Bullet
             Visibility: public
             Type: class constructor

        Name: Bullet
             Description: Class Constructor Overloader of Bullet
             Visibility: public
             Type: class constructor

        Name: HitCollision
             Description: Checks when pilot, or pilot's tank gets shot.
             Visibility: public
             Type: void
             Argument: float

        Name: ~Bullet
             Description: Deconstructor for Bullet, removes bullet from the scene.
             Type: Deconstructor

        Name: DestroyBullet
             Description: Destroys the bullet when it leaves off screen.
             Visibility: public
             Type: float
             Argument: class

        Name: CollisionCheck
             Description: Checks to see if collision is true
             Visibility: public
             Type: bool
             Argument: class

     **Operations**:

        Name: _textureBullet
             Description: Creates the texture for the TankTurret
             Type: class
             Visibility: private

        Name: _hitboxBullet
             Description: Bullet AABB hitbox
             Type: class
             Visibility: private

        Name: pilot
             Description: Used in hit collision check, ejects pilot if tank is destroyed
             Type: class
             Visibility: private

        Name: bodyTank
             Description: Used in hit collision check if tank is destroyed when hit.
             Type: class
             Visibility: private
